clear all;
clc;
locationOfFiles = '../CSV/';
extension = '*.csv';
files = dir(strcat(locationOfFiles, extension));

traces = zeros(length(files), 50);
hamming = zeros(length(files), 8, 64);
coef = zeros(8, 64, 50);
inARow = 1;
lastGuess = zeros(1,8);
guessIndicies = zeros(1,8);

for traceNumber=1:size(files)
    
    % getting File, File name, message, and key
    fileName = strsplit(files(traceNumber).name, '=');

    fileKey = strtok(fileName(2), '_');
    fileMessage = strtok(fileName(3), '_');
    fileCryp = strtok(fileName(4), '.');
    completePath = strcat(locationOfFiles, files(traceNumber).name);
    
    % getting trace data from file
    traces(traceNumber,:) = csvread(completePath, 5726, 1, [5726, 1, 5775, 1]);

    %getting message from file name
    message = hex2bi(char(fileMessage));

    %getting hamming distance from message
    hamming(traceNumber,:,:) = DESHAMM(message, 'ENC', message);

    
    % get correlation coefficients for all SBoxs
    for SBox=1:8
        coef(SBox,:,:) = corr(permute(hamming(1:traceNumber,SBox,:), ... 
          [1 3 2]),traces(1:traceNumber,:));
          
        % Get highest correlation coefficient for all SBoxs
        [TraceMax, TraceIndex] = max(traces(SBox,:));
        [GuessMax, GuessIndex] = max(coef(SBox,:,TraceIndex));
        guessIndicies(1, SBox) = GuessIndex;
    end
    
    % Display the currect indicies
    display(guessIndicies);

    % check to see if it is the same as the last trace
    if(lastGuess == guessIndicies)
        
        % Check to see if it has been the same 100 times
        if(inARow == 100)
            break;
        end
        
        % if it is equal, increment counter
        inARow = inARow +1;
        display(inARow);

    else
        % if it is different, reset the counter
        lastGuess = guessIndicies;
        display(lastGuess);
        inARow = 1;
    end
end

% Display correct indicies and how many traces it took and how many in a
% row was achieved
display(guessIndicies);
display(inARow);
display(traceNumber);

%correct key for our selection was 6A65786A65786A65
display(FindKey(guessIndicies));
