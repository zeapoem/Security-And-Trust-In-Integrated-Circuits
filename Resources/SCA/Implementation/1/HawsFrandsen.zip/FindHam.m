function ham = FindHam(A, B, index)   

a = [A(index(1)) A(index(2)) A(index(3)) A(index(4))];
b = [B(index(1)) B(index(2)) B(index(3)) B(index(4))];
ham = xor(a,b);
