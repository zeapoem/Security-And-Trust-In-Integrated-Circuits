import math
import operator
import os

import numpy as np
from itertools import imap

from DES_enc_bit import *

def get_trace_files(start, end):
    #traces = []
    for csv_file in os.listdir(r'c:\users\vip\desktop\csv'): #[start:end]:
        m = csv_file.find('m=')+2
        message = csv_file[m:m+16]
        c = csv_file.find('c=')+2
        cyphertext = csv_file[c:c+16]
        with open(os.path.join(r'c:\users\vip\desktop\csv', csv_file)) as tracefile:
            content = tracefile.read()
        content = content.split('\n')
        try:
            content.remove('')
        except Exception:
            pass
        tuplepairs = []
        tuplepairs.append((message, cyphertext))
        for entry in content:
            a, b = entry.split(', ')
            tuplepairs.append((float(a), float(b)))
        yield tuplepairs
    #return traces

def HD(num1, num2):
    """input is two integers. output is hamming distance as an integer"""
    num1 = bin(num1).replace('0b','').zfill(64) # 64 bit representation of num1
    num2 = bin(num2).replace('0b','').zfill(64) # 64 bit representation of num2
    return sum(imap(operator.ne, num1, num2))

def break_encryption():
    start = 0
    end = 500
    correlation = {}
    best_guess = 0
    prev_guess = 65
    consecutive_guesses = 0
    keys = {}
    for box in range(1, 9):
        # for each sbox, find greatest power correlation from 500 traces
        #traces = get_trace_files(start, end)
        count = 0
        max_power = []
        hamming_distances = [[] for i in range(64)]
        for trace in get_trace_files(start, end):
            count += 1
            # initial plaintext of trace file
            plaintxt = trace[0][0]
            max_power.append(max([t[1] for t in trace[5700:5800]]))
            # send plain text through initial permutation
            mixtxt = Initial_permutation(int(plaintxt,16))
            r_0 = mixtxt & 0xffffffff
            # expand right half of plaintxt
            r_0exp = expansion_permuatation(r_0)
            exp_bits = (r_0exp & (0xfc0000000000 >> ((box - 1) * 6))) >> ((8-box) * 6)
            r_0 = bin(r_0).replace('0b', '').zfill(32)
            l_0 = bin((mixtxt >> 32) & 0xffffffff).replace('0b', '').zfill(32)
            num_r0, num_l0 = get_bits(r_0, l_0, box)
            for key_guess in range(2**6):
                xored = key_guess ^ exp_bits
                sbox_output = sbox(box, xored)
                # compute the bits of r_1 we care about
                num_r1 = sbox_output ^ num_l0
                # store the hamming distance between r_0 and r_1
                hamming_distances[key_guess].append(HD(num_r1, num_r0))
            if count > 4:
                best_guess = correlate(hamming_distances, max_power)
                if best_guess == prev_guess:
                    consecutive_guesses += 1
                else:
                    consecutive_guesses = 0
                if consecutive_guesses >= 100:
                    print "Sbox%s guess found: %s, Number of traces: %s" % (box, best_guess, count)
                    keys['sbox%s' % box] = best_guess
                    break
                else:
                    prev_guess = best_guess
                #correlation['sbox%s' % box].append(correlate(hamming_distances, trace[1:]
    key = 0
    for i in range(1, 9):
        key |= keys["sbox%s" % i]
        key = key << 6
    key = de_permute_c2(key)
    print "Subkey: %s" % hex(int(key, 2))
    missing_bit_index = [9, 18, 22, 25, 35, 38, 43, 54]
    crypt_txt = int(trace[0][1], 16)
    encrypted_msg = DES_enc_56(int(plaintxt, 16), int(key, 2))
    if crypt_txt == encrypted_msg:
        print "Success!"
    else:
        for a in range(2):
            for b in range(2):
                for c in range(2):
                    for d in range(2):
                        for e in range(2):
                            for f in range(2):
                                for g in range(2):
                                    for h in range(2):
                                        key = key[:9] + str(a) \
                                            + key[10:18] + str(b) \
                                            + key[19:22] + str(c) \
                                            + key[23:25] + str(d) \
                                            + key[26:35] + str(e) \
                                            + key[36:38] + str(f) \
                                            + key[39:43] + str(g) \
                                            + key[44:54] + str(h) \
                                            + key[55:]
                                        encrypted_msg = DES_enc_56(int(plaintxt, 16),
                                                                   int(key, 2))
                                        if crypt_txt == encrypted_msg:
                                            print "Success!"
                                            final_key = de_permute_c1(key)
                                            print "Final Key: %s" % hex(int(final_key, 2))
# we now have a dictionary of correlations of each box for 500 traces each



def de_permute_c1(key):
    permutation = [8, 16, 24, 56, 52, 44, 36, 0,
                   7, 15, 23, 55, 51, 43, 35, 0,
                   6, 14, 22, 54, 50, 42, 34, 0, 
                   5, 13, 21, 53, 49, 41, 33, 0,
                   4, 12, 20, 28, 48, 40, 32, 0,
                   3, 11, 19, 27, 47, 39, 31, 0,
                   2, 10, 18, 26, 46, 38, 30, 0,
                   1, 9,  17, 25, 45, 37, 29, 0]
    depermuted_key = ''
    for bit in permutation:
        if bit == 0:
            depermuted_key += str(depermuted_key[len(depermuted_key) - 7:].count('1') % 2)
        else:
            depermuted_key += key[bit-1]
    return depermuted_key

def de_permute_c2(key):
    permutation = [ 5, 24,  7, 16,  6, 10, 20, 18,  0,
                   12,  3, 15, 23,  1,  9, 19,  2,  0,
                   14, 22, 11,  0, 13,  4,  0, 17, 21,
                    8, 47, 31, 27, 48, 35, 41,  0, 46,
                   28,  0, 39, 32, 25, 44,  0, 37, 34,
                   43, 29, 36, 38, 45, 33, 26, 42,  0,
                   30, 40]
    key = bin(key).replace('0b', '').zfill(48)
    depermuted_key = ''
    for bit in permutation:
        if bit == 0:
            depermuted_key += '0'
        else:
            depermuted_key += key[bit-1]
    depermuted_key = int(depermuted_key, 2)
    key_r = depermuted_key & 0xfffffff
    key_l = (depermuted_key >> 28) & 0xfffffff
    upper_r = (0x1 & key_r) << 27
    upper_l = (0x1 & key_l) << 27
    key_r = (key_r >> 1) & 0xfffffff
    key_l = (key_l >> 1) & 0xfffffff
    key_r = key_r | upper_r
    key_l = key_l | upper_l
    depermuted_key = (key_l << 28) | key_r
    return bin(depermuted_key).replace('0b','').zfill(56)

def get_bits(right, left, box):
    """input is string representation of 32 bit binary numbers. the bits are
    rearranged to correspond to the output of the sbox after its sent through
    the pbox. numbers are then converted to integers and returned"""
    if box == 1:
        r_bits = right[8] + right[16] + right[22] + right[30]
        r_bits = int(r_bits, 2)
        l_bits = left[8] + left[16] + left[22] + left[30]
        l_bits = int(l_bits, 2)
    elif box == 2:
        r_bits = right[12] + right[27] + right[1] + right[17]
        r_bits = int(r_bits, 2)
        l_bits = left[12] + left[27] + left[1] + left[17]
        l_bits = int(l_bits, 2)
    elif box == 3:
        r_bits = right[23] + right[15] + right[29] + right[5]
        r_bits = int(r_bits, 2)
        l_bits = left[23] + left[15] + left[29] + left[5]
        l_bits = int(l_bits, 2)
    elif box == 4:
        r_bits = right[25] + right[19] + right[9] + right[0]
        r_bits = int(r_bits, 2)
        l_bits = left[25] + left[19] + left[9] + left[0]
        l_bits = int(l_bits, 2)
    elif box == 5:
        r_bits = right[7] + right[13] + right[24] + right[2]
        r_bits = int(r_bits, 2)
        l_bits = left[7] + left[13] + left[24] + left[2]
        l_bits = int(l_bits, 2)
    elif box == 6:
        r_bits = right[3] + right[28] + right[10] + right[18]
        r_bits = int(r_bits, 2)
        l_bits = left[3] + left[28] + left[10] + left[18]
        l_bits = int(l_bits, 2)
    elif box == 7:
        r_bits = right[31] + right[11] + right[21] + right[6]
        r_bits = int(r_bits, 2)
        l_bits = left[31] + left[11] + left[21] + left[6]
        l_bits = int(l_bits, 2)
    else:
        r_bits = right[4] + right[26] + right[14] + right[20]
        r_bits = int(r_bits, 2)
        l_bits = left[4] + left[26] + left[14] + left[20]
        l_bits = int(l_bits, 2)
    return r_bits, l_bits

def correlate(hamming_distances, max_power):
    correlations = {}
    for key_guess in range(64):
        correlations[key_guess] = np.corrcoef(hamming_distances[key_guess], max_power)[0, 1]
    best_guess = max(correlations, key=correlations.get)
    #print best_guess
    return best_guess

break_encryption()