function [ keys ] = gen_keys()

    keys = (dec2bin(0:63, 6) - '0');
    
    %keys = zeros(64, 64);
    
    %for i=(1:64)
    %    keys(i,[10,51,34,60,49,17]) = combos(i,:);
    %    %keys(i,[10,51,34,60,49,17]) = [1 1 1 0 0 0];
    %end
end
