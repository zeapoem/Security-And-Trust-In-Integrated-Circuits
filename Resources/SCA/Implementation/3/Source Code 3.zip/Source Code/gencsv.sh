#!/bin/bash
 
# This script automatically converts a number MAX of traces from .bin
# to .csv using the example program from the DPA website. The .bin
# files must be stored in the folder specified in SOURCE below. This
# script should be run from the directory containing the SOURCE directoy,
# this script, and the C program.
#
# Make sure this file has been marked executable with chmod u-x getcsv
#
# You also need the example C program to be marked as executable
# and its filename changed in the EXECUTABLE variable below
 
# Using this script, the Comma Separated Value files will be stored
# in the CSV folder (the name can be changed in the OUTPUT variable).
# The resulting filename will include the index number as:
# 1-wave_DES_HW_2006-04-07_19-08-36__k=6a65786a65786a65_m=67c6697351ff4aec_c=c54baee5fc80756a.bin.csv
# 2-wave_DES_HW_2006-04-07_19-08-39__k=6a65786a65786a65_m=29cdbaabf2fbe346_c=857f106855100811.bin.csv
# 3-wave_DES_HW_2006-04-07_19-08-42__k=6a65786a65786a65_m=7cc254f81be8e78d_c=392ee00c1d55ceb9.bin.csv
#
# It will also create the file mValues and cValues that will contain
# the extracted m= and c= data from the filenames accordingly. i. e.
# the file cValues will contain:
# c54baee5fc80756a
# 857f106855100811
# 392ee00c1d55ceb9
#
 
 
 
i=0
MAX=2000
SOURCE=secmatv1_2006_04_0809
OUTPUT=secmatv1_2006_04_0809/CSV
EXECUTABLE=bin2csv
 
[ -x $EXECUTABLE ] || { echo "Error: The conversion program is not marked as executable"; exit; };
 
[ -d $SOURCE ] || { echo "Error: The source directory does not exist"; exit; };
 
[ -d $OUTPUT ] || mkdir $OUTPUT;
 
# Delete the old values string tables
[ -e mValues ] && rm mValues;
[ -e cValues ] && rm cValues;
 
# Main Loop
 
for f in $( ls ${SOURCE}/);
 
do  [ $i -lt $MAX ] && {
            (( i++ ));
            echo "Converting $i";
            ./$EXECUTABLE $SOURCE/$f $OUTPUT/$i-$f.csv;
            echo $( expr "$f" : '.*m=\(.*\)_.*') >> mValues;
            echo $( expr "$f" : '.*c=\(.*\)\.bin') >> cValues;
            };
 
done;
