function [data,messages] = load_csvs( d )

i = 1;

files = dir([d '*.csv']);

set = false;

for file = files'
    tmp = load([d file.name]);
    
    if ~set
        data = zeros(size(files, 1), size(tmp, 1));
        messages = repmat(char(0), size(files, 1), 16);
        
        size(data)
        set = true;
    end
    
    data(i,:) = tmp(:,2);
    [~,tok] = regexp(file.name, '_m=([A-Fa-f0-9]{16})', 'match', 'tokens');
    %tok{1}{1}
    messages(i,:) = char(tok{1}{1}');
    
    i = i + 1;
end

end
