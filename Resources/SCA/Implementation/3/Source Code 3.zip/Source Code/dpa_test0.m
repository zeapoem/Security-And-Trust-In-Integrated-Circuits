function [diffs] = dpa_test0(messages, sample_data, S)

key_guesses = gen_keys();

diffs = zeros(size(key_guesses, 1), size(sample_data, 2));

for kg_idx = (1:size(key_guesses, 1))
    
    sumA = zeros(1, size(sample_data, 2));
    sumA_num = 0;
    sumB = zeros(1, size(sample_data, 2));
    sumB_num = 0;
    
    kg = key_guesses(kg_idx,:);
    
    for i=(1:size(messages, 1))
        check = check_cond(kg, hex2bin64(messages(i,:)),S);
        if check == 1
            sumA = sumA + sample_data(i,:);
            sumA_num = sumA_num + 1;
        elseif check == 0
            sumB = sumB + sample_data(i,:);
            sumB_num = sumB_num + 1;
        elseif check == 2
            sumA = sumA + sample_data(i,:);
            sumA_num = sumA_num + 1;
            sumB = sumB + sample_data(i,:);
            sumB_num = sumB_num + 1;
        end
        
    end
    
    sumA_num;
    sumB_num;
    
    sumA = sumA / sumA_num;
    sumB = sumB / sumB_num;
    sum_diff = sumA - sumB;
    
    diffs(kg_idx,:) = sum_diff(:);
    
    %clf;
    %hold on;
    %plot(sum_diff);
    %kg([10,51,34,60,49,17])
end

end

%{

     1     1     1     0     0     0    56
     0     0     1     0     1     1    11
     1     1     1     0     1     1    59 
     1     0     0     1     1     0    38 
     0     0     0     0     0     0     0 
     0     0     1     1     0     1    13 
     0     1     1     0     0     1    25 
     1     1     0     1     1     1    55

%}