

final_ntraces = zeros(1, 50);

for i=1:50
    
    traceset = randperm(size(sample_data, 1));
    
    final_ntraces(i) = minimize_traces(messages(traceset,:), sample_data(traceset,5600:6000), 5, correct_idx);
end

final_ntraces
