function [ binary_vec ] = hex2bin64( str_vec )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

binary_vec = ([dec2bin(hex2dec(str_vec(1:8)), 32) dec2bin(hex2dec(str_vec(9:16)), 32)] - '0');

end