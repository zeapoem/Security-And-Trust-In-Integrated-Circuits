function [ ntraces ] = minimize_traces( messages, sample_data, resolution, correct_indices )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

ntraces = size(sample_data, 1)/2;

delta = ntraces/2;

while true
    
    ntraces
    keyguess = zeros(1,8);
    for S=1:8
        S
        diffs = dpa_test0(messages(1:round(ntraces),:), sample_data(1:round(ntraces),:), S);
        
        [~,keyguess(S)] = max(max(diffs, [], 2));
    end
    
    keyguess
    correct_indices
    if keyguess == correct_indices
        ntraces = ntraces - delta;
    else
        ntraces = ntraces + delta;
    end
    
    if(delta < resolution)
        return
    end
    delta = delta / 2;
end

end
