clc;
clear all;


%realX = fopen('vout.txt', 'r');
%b = csvread('test.csv');

%arr = b(:, 2);

files = dir('./CSV/*.csv');

arr = zeros(length(files), 20003);

% for t=1:length(files)
%     b = csvread(strcat('./CSV/', files(t).name));
%     arr(t, :) = b(:, 2);
% end

messages = textread('mValues', '%s');



key = '6a65786a65786a65';
%key2 = [0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1 0 1 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1 0 1 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1];
key2 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
%dec = hex2dec(messages(1));
%bin = dec2bin(dec);

outs = zeros(length(files), 64, 8);
iter = 0;
iOld = zeros(8,1);

for j = 1:length(files)
    b = csvread(strcat('./CSV/', files(j).name));
    arr(j, :) = b(:, 2);
    
    bin = '';
    str = char(messages(j));
    for i=1:length(str)
    
        h = str(i);
        switch h
            case {'0'}
                b = ' 0 0 0 0 ';
            case {'1'}
                b = ' 0 0 0 1 ';
            case {'2'}
                b = ' 0 0 1 0 ';
            case {'3'}
                b = ' 0 0 1 1 ';
            case {'4'}
                b = ' 0 1 0 0 ';
            case {'5'}
                b = ' 0 1 0 1 ';
            case {'6'}
                b = ' 0 1 1 0 ';
            case {'7'}
                b = ' 0 1 1 1 ';
            case {'8'}
                b = ' 1 0 0 0 ';
            case {'9'}
                b = ' 1 0 0 1 ';
            case {'A', 'a'}
                b = ' 1 0 1 0 ';
            case {'B', 'b'}
                b = ' 1 0 1 1 ';
            case {'C', 'c'}
                b = ' 1 1 0 0 ';
            case {'D', 'd'}
                b = ' 1 1 0 1 ';
            case {'E', 'e'}
                b = ' 1 1 1 0 ';
            case {'F', 'f'}
                b = ' 1 1 1 1 ';
        end
        bin = strcat(bin, b);
    end
    arrBin = str2num(bin);
    %out = {0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 };

    %disp(out);
    outs(j, :, 1) = DES1(arrBin, 'ENC', key2);
    outs(j, :, 2) = DES2(arrBin, 'ENC', key2);
    outs(j, :, 3) = DES3(arrBin, 'ENC', key2);
    outs(j, :, 4) = DES4(arrBin, 'ENC', key2);
    outs(j, :, 5) = DES5(arrBin, 'ENC', key2);
    outs(j, :, 6) = DES6(arrBin, 'ENC', key2);
    outs(j, :, 7) = DES7(arrBin, 'ENC', key2);
    outs(j, :, 8) = DES8(arrBin, 'ENC', key2);
    Gcorr = zeros(8, 64, 11);
    I = zeros(8, 1);
    Ish = zeros(8, 1);
    for mk=1:8
        Gcorr(mk, :, :) = corr(outs(1:j, :, mk),arr(1:j, 5739:5749));
        [~,Ish(mk)] = max(max(Gcorr(mk, :, :)));
        [~,I(mk)] = max(Gcorr(mk, :, Ish(mk)));
    end
    
    disp(I);
    if ~isequal(iOld, I)
        disp(iter);
        iter = 0;
    end
    iter = iter+1;
    if iter > 100
        return;
    end
    iOld = I;
    
end

%disp(outs)
%for i=1:64
%Gcorr = corr(outs,arr(:, 5744));
% plot correlation
time = 1:20003;
hold on;
plot(Gcorr);title('correct guess');
[~,I] = max(Gcorr); %sample point with max correlation
%end
