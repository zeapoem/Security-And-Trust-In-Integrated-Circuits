clc;
clear all;


%realX = fopen('vout.txt', 'r');
%b = csvread('test.csv');

%arr = b(:, 2);

files = dir('./CSV/*.csv');

arr = zeros(length(files), 20003);

% for t=1:length(files)
%     b = csvread(strcat('./CSV/', files(t).name));
%     arr(t, :) = b(:, 2);
% end

messages = textread('mValues', '%s');

for j=1:length(files)
    b = csvread(strcat('./CSV/', files(j).name));
    arr(j, :) = b(:, 2);
end


key = '6a65786a65786a65';
%key2 = [0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1 0 1 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1 0 1 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1];
key2 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
%dec = hex2dec(messages(1));
%bin = dec2bin(dec);

outs = zeros(length(files), 4096, 4);
iter = 0;
iOld = zeros(4,1);

for j = 1:length(files)
    if mod(j, 2) == 0
        [maxVal, maxInd] = min(arr(:, 5744));
    else
        [maxVal, maxInd] = max(arr(:, 5744));
    end
    arr2(j, 1) = maxVal;
    arr(maxInd, 5744) = NaN;
    
    bin = '';
    str = char(messages(maxInd));
    for i=1:length(str)
    
        h = str(i);
        switch h
            case {'0'}
                b = ' 0 0 0 0 ';
            case {'1'}
                b = ' 0 0 0 1 ';
            case {'2'}
                b = ' 0 0 1 0 ';
            case {'3'}
                b = ' 0 0 1 1 ';
            case {'4'}
                b = ' 0 1 0 0 ';
            case {'5'}
                b = ' 0 1 0 1 ';
            case {'6'}
                b = ' 0 1 1 0 ';
            case {'7'}
                b = ' 0 1 1 1 ';
            case {'8'}
                b = ' 1 0 0 0 ';
            case {'9'}
                b = ' 1 0 0 1 ';
            case {'A', 'a'}
                b = ' 1 0 1 0 ';
            case {'B', 'b'}
                b = ' 1 0 1 1 ';
            case {'C', 'c'}
                b = ' 1 1 0 0 ';
            case {'D', 'd'}
                b = ' 1 1 0 1 ';
            case {'E', 'e'}
                b = ' 1 1 1 0 ';
            case {'F', 'f'}
                b = ' 1 1 1 1 ';
        end
        bin = strcat(bin, b);
    end
    arrBin = str2num(bin);
    %out = {0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 };

    %disp(out);
    outs(j, :, 1) = DES2_1(arrBin, 'ENC', key2);
    outs(j, :, 2) = DES2_2(arrBin, 'ENC', key2);
    outs(j, :, 3) = DES2_3(arrBin, 'ENC', key2);
    outs(j, :, 4) = DES2_4(arrBin, 'ENC', key2);
    Gcorr = zeros(4, 4096, 1);
    I = zeros(4, 1);
    Ish = zeros(4, 1);
    for mk=1:4
        Gcorr(mk, :, 1) = corr(outs(1:j, :, mk),arr2(1:j, 1));
        [~,Ish(mk)] = max(max(Gcorr(mk, :, 1)));
        [~,I(mk)] = max(Gcorr(mk, :, 1));
    end
    
    disp(j);
    disp(I);
    if ~isequal(iOld, I)
        disp(iter);
        iter = 0;
    end
    iter = iter+1;
    if iter > 100
        return;
    end
    iOld = I;
    
end

%disp(outs)
%for i=1:64
%Gcorr = corr(outs,arr(:, 5744));
% plot correlation
time = 1:20003;
hold on;
plot(Gcorr);title('correct guess');
[~,I] = max(Gcorr); %sample point with max correlation
%end